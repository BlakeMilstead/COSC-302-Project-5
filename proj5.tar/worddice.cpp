/*
Blake Milstead & Randy Lin
COCS 302 
Professor Emrich
4-20-2023
Project 5

Our program takes in two files, one containing dice and one containing words.
It then tells the user if the words can be made using one letter per dice. Our program
converts the two files into a network flow graph with a sink, soure, and nodes
within an adjacency matrix. The max weight between edges is 1 for all edges. 
It then uses Edmonds-Karp algorithm to find the max flow of this adjaceny matrix.
If the max flow is equal to the size of the word being checked then the word can
be spelled. If it can be spelled it tells the user which die are used and if it can 
not be spelled it tells the user so.
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <queue>
#include <algorithm>
#include <limits.h>

using namespace std;

//Geeks for Geeks was used for our BFS and Edmonds-Karp algorithm 

bool bfs(vector<vector<int>> &rGraph, int &source, int &sink, vector<int> &parent ){ 
    vector<bool> visited(rGraph.size(), false);
    queue<int> que;
    que.push(source);
    visited[source] = true;
    parent[source] = -1;

    while(!que.empty()){
        int u = que.front();
        que.pop();

        for(int i = 0; i < rGraph.size(); i++){
            if(visited[i] == false && rGraph[u][i] > 0){
                if(i == sink){
                    parent[i] = u;
                    return true;
                }
                que.push(i);
                parent[i] = u;
                visited[i] = true;
            }
        }
    }

    return false;
}

int karp(vector<vector<int>> &graph, int source, int sink, vector<int> &diceTrace, int &counter){ //Added diceTrace vector and counter int for figuring our dice backtrace to the GeeksForGeeks imp
    int u, v;

    vector<vector<int>> rGraph(graph.size(), vector<int> (graph.size(), 0)); 
    for (int i = 0; i < graph.size(); i++)
    {
        for (int j = 0; j < graph[i].size(); j++)
        {
            rGraph[i][j] = graph[i][j];
        }
    }

    vector<int> parent (graph.size());

    int maxFlow = 0;

    while(bfs(rGraph, source, sink, parent)){
        int pathFlow = INT_MAX;
        for(v = sink; v != source; v = parent[v]){
            u = parent[v];
            pathFlow = min(pathFlow, rGraph[u][v]);
        }

        for (v = sink; v != source; v = parent[v]){
            u = parent[v];
            rGraph[u][v] -= pathFlow;
            rGraph[v][u] += pathFlow;
        }

        maxFlow += pathFlow;
    }
        
    //This finds the backtrace of the dice used to create the given word
    int wordPlace = counter+1; //counter+1 = source + numDie
    for(int i = 0; i < wordPlace; i++){
      for(int j = 0; j < rGraph.size(); j++){
        if (rGraph.size()-1 > i+wordPlace){ //Ensuring we do not check outside the bounds of the rGraph adjMatrix
          if (rGraph[i+wordPlace][j] != 0){ //Check if there is an edge at a word letter location 
            diceTrace.push_back(j-1); //Subtract 1 to account for source node, makes dice number zero indexed
          }
        }
      }
    }
    return maxFlow;
}

int main(int argc, char *argv[]){
    ifstream fnF, fnS;

    if(argc != 3){
        cerr << "Usage Error: worddice Dice.txt Words.txt";
        return -1;
    }

    fnF.open(argv[1]);
    fnS.open(argv[2]);
    if(!fnF.is_open())
    {
        cerr << "Dice File Failed to Open";
        return -1;
    }
    if (!fnS.is_open())
    {
        cerr << "Words File Failed to Open";
        return -1;
    }

    string temp;

    vector<vector<int>> adjMat;
    map<int, string> diceMap; //Keeps track of the dice letters to check for edges with the word letters later
    map<int, string>:: iterator mit;

    int counter = 0;

    vector<int> tempVector;

    tempVector.push_back(0); //So our source row will start with a 0 edge to itself

    while(fnF >> temp){ //Getting Dice
        tempVector.push_back(1); //So source row has an edge to every dice
        counter++;
        diceMap.insert({counter, temp});
    }
    
    adjMat.push_back(tempVector); //Creating Source Row of AdjMatrix

    char tempLet;
    while (fnS >> temp){ //Main while loop
        int adjMatSize = counter+2+temp.size();

        adjMat[0].resize(adjMatSize, 0); //adds letters of word to source row
        
        tempVector.clear();
        tempVector.resize(adjMatSize, 0);

        for (int i = 0; i < counter; i++){ // Creating Dice Rows of AdjMatrix
            adjMat.push_back(tempVector);
        }

        tempVector[0] = 0;
        tempVector[adjMatSize-1] = 1; //sets the word rows to have an edge to the sink

        for (int i = 0; i < temp.size(); i++){ // Creating Word Rows of AdjMatrix
            adjMat.push_back(tempVector);
        }

        tempVector[adjMatSize-1] = 0; //Making sure sink row has zero edges
        adjMat.push_back(tempVector); //Sink row
    
        for(int i = 0; i < temp.length(); i++){ //Checks for edges between dice and letters
            tempLet = temp[i];
            for(mit = diceMap.begin(); mit != diceMap.end(); mit++){
                for(int j = 0; j < mit->second.length(); j++){
                    if(mit->second[j] == tempLet){
                        adjMat[mit->first][counter+i+1] = 1;
                    }
                }
            }
        }

        vector<int> diceTrace;

        if(karp(adjMat, 0, adjMat.size()-1, diceTrace, counter) != temp.size()){ //if Edmonds-Karp returns a maxFlow equal to the size of the word it can be spelled else can't
            cout << "Cannot spell " << temp << endl;
        } else {
            for(int i = 0; i < diceTrace.size(); i++){
                cout << diceTrace[i];
                if(i != diceTrace.size()-1){
                    cout << ",";
                } else {
                    cout << ": ";
                }
            }
            cout << temp << endl;
        }
        adjMat.resize(1); //Reset the adjMat for next word, keeping the sink row
    }
    fnF.close();
    fnS.close();
}